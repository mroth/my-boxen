# Install Github for Mac Puppet Module for Boxen

GitHub for Mac - The easiest way to share your code with GitHub

See mac.github.com for more. 

## Usage

```include githubapp```


## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
