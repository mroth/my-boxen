# iTerm2 Puppet Module for Boxen

## Usage

```puppet
# Stable release
include iterm2::stable

# Dev release
include iterm2::dev
```

## Required Puppet Modules

* boxen
* stdlib

