# F.lux Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-flux.png)](https://travis-ci.org/boxen/puppet-flux)

## Usage

```puppet
include flux
```

## Required Puppet Modules

* boxen

## Developing

Write code.

Run `script/cibuild`.
