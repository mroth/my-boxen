# Github for Mac Puppet Module for Boxen

Install [Github for Mac](http://mac.github.com/), The easiest way to share your code with GitHub.

## Usage

```puppet
include github_for_mac
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
