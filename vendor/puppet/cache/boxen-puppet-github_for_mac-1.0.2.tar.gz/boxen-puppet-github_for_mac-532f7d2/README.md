# Install GitHub for Mac Puppet Module for Boxen
[![Build
Status](https://travis-ci.org/boxen/puppet-github_for_mac.png?branch=master)](https://travis-ci.org/boxen/puppet-github_for_mac)

GitHub for Mac - The easiest way to share your code with GitHub

See mac.github.com for more.

## Usage

```include github_for_mac```


## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
