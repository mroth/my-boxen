[![Build
Status](https://travis-ci.org/boxen/puppet-hipchat.png?branch=master)](https://travis-ci.org/boxen/puppet-hipchat)

# HipChat for Mac

## Usage

```puppet
include hipchat
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
